"""
Industry-Level Drug Import Script
Robust ETL-safe version
"""

from app import app, db
from models import Drug
import pandas as pd
import re
import math
from datetime import datetime


# ---------------- SAFE HELPERS ---------------- #

def safe_str(value, default=None):
    if pd.isna(value):
        return default
    return str(value).strip()


def safe_int(value, default=0):
    if pd.isna(value):
        return default
    try:
        return int(float(value))
    except:
        return default


def safe_float(value, default=0.0):
    if pd.isna(value):
        return default
    try:
        return float(value)
    except:
        return default


def extract_number(value, default=0.0):
    """
    Extract numeric part from strings like:
    4000mg, 20 mg, 60000 IU
    """
    if pd.isna(value):
        return default

    match = re.search(r"\d+\.?\d*", str(value))
    return float(match.group()) if match else default


def safe_bool(value, default=True):
    if pd.isna(value):
        return default
    return str(value).strip().upper() == "TRUE"


# ---------------- MAIN IMPORT ---------------- #

def import_drugs_from_csv():

    with app.app_context():
        try:
            print("Reading CSV file...")

            # AUTO-DETECT delimiter (comma or tab)
            df = pd.read_csv("data/drugs_extended.csv", sep=None, engine="python")

            # Clean column names
            df.columns = df.columns.str.strip()

            print("Columns detected:", df.columns.tolist())
            print(f"Total rows found: {len(df)}")

            added_count = 0
            updated_count = 0
            skipped_count = 0

            for idx, row in df.iterrows():

                drug_name = safe_str(row.get("drug_name"))

                # Skip invalid header rows accidentally inside file
                if not drug_name or drug_name.lower() == "drug_name":
                    skipped_count += 1
                    continue

                category = safe_str(row.get("category"))

                # Skip if mandatory field missing
                if not category:
                    print(f"Skipping row {idx} - Missing category")
                    skipped_count += 1
                    continue

                existing_drug = Drug.query.filter(
                    Drug.drug_name.ilike(drug_name)
                ).first()

                payload = dict(
                    generic_name=safe_str(row.get("generic_name")),
                    brand_names=safe_str(row.get("brand_names")),
                    category=category,
                    drug_class=safe_str(row.get("drug_class")),
                    indication=safe_str(row.get("indication")),
                    mechanism_of_action=safe_str(row.get("mechanism_of_action")),
                    side_effects=safe_str(row.get("side_effects")),
                    dosage_forms=safe_str(row.get("dosage_forms")),
                    standard_dosage=safe_str(row.get("standard_dosage")),
                    max_daily_dose=extract_number(row.get("max_daily_dose")),
                    age_min=safe_int(row.get("age_min"), 0),
                    age_max=safe_int(row.get("age_max"), 120),
                    kidney_safe=safe_str(row.get("kidney_safe"), "YES"),
                    liver_safe=safe_str(row.get("liver_safe"), "YES"),
                    pregnancy_category=safe_str(row.get("pregnancy_category")),
                    pregnancy_safe=safe_str(row.get("pregnancy_safe"), "YES"),
                    price=extract_number(row.get("price")),
                    prescription_required=safe_bool(row.get("prescription_required"), True),
                    food_interactions=safe_str(row.get("food_interactions")),
                    updated_at=datetime.utcnow()
                )

                if existing_drug:
                    for key, value in payload.items():
                        setattr(existing_drug, key, value)
                    updated_count += 1
                else:
                    drug = Drug(
                        drug_name=drug_name,
                        created_at=datetime.utcnow(),
                        **payload
                    )
                    db.session.add(drug)
                    added_count += 1

                # Commit every 50 rows (better performance)
                if (idx + 1) % 50 == 0:
                    db.session.commit()
                    print(f"Processed {idx + 1}/{len(df)} rows...")

            db.session.commit()

            print("\n" + "=" * 60)
            print("IMPORT COMPLETE ✅")
            print("=" * 60)
            print(f"Added: {added_count}")
            print(f"Updated: {updated_count}")
            print(f"Skipped: {skipped_count}")
            print(f"Total in DB: {Drug.query.count()}")
            print("=" * 60)

        except Exception as e:
            print("ERROR DURING IMPORT")
            print(str(e))
            import traceback
            traceback.print_exc()
            db.session.rollback()


if __name__ == "__main__":
    import_drugs_from_csv()