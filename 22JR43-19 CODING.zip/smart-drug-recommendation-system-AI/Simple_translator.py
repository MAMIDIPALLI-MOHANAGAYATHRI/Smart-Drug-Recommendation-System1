"""
Simple Google Translate Integration
Provides basic translation for patient-facing content
Uses googletrans library (free, no API key needed)
"""

from typing import Dict, List, Optional

try:
    from googletrans import Translator, LANGUAGES
    HAS_TRANSLATOR = True
except ImportError:
    HAS_TRANSLATOR = False
    print("⚠️ Google Translate library not installed. Install with: pip install googletrans==4.0.0-rc1")


class SimpleTranslator:
    """Simple translation service for medical content"""
    
    # Supported languages for medical interface
    SUPPORTED_LANGUAGES = {
        'en': 'English',
        'hi': 'Hindi (हिंदी)',
        'te': 'Telugu (తెలుగు)',
        'ta': 'Tamil (தமிழ்)',
        'kn': 'Kannada (ಕನ್ನಡ)',
        'ml': 'Malayalam (മലയാളം)',
        'mr': 'Marathi (मराठी)',
        'bn': 'Bengali (বাংলা)',
        'gu': 'Gujarati (ગુજરાતી)',
        'pa': 'Punjabi (ਪੰਜਾਬੀ)'
    }
    
    def __init__(self):
        if HAS_TRANSLATOR:
            self.translator = Translator()
        else:
            self.translator = None
    
    def translate_text(
        self,
        text: str,
        target_lang: str = 'hi',
        source_lang: str = 'en'
    ) -> Dict:
        """
        Translate text to target language
        
        Args:
            text: Text to translate
            target_lang: Target language code (e.g., 'hi' for Hindi)
            source_lang: Source language code (default 'en')
        
        Returns:
            Translation result dictionary
        """
        if not HAS_TRANSLATOR:
            return {
                'success': False,
                'error': 'Translator not available',
                'original': text
            }
        
        if not text or not text.strip():
            return {
                'success': False,
                'error': 'Empty text',
                'original': text
            }
        
        try:
            # Translate
            result = self.translator.translate(
                text,
                src=source_lang,
                dest=target_lang
            )
            
            return {
                'success': True,
                'original': text,
                'translated': result.text,
                'source_lang': source_lang,
                'target_lang': target_lang,
                'confidence': result.extra_data.get('confidence', 1.0) if hasattr(result, 'extra_data') else 1.0
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'original': text
            }
    
    def translate_medical_instructions(
        self,
        instructions: Dict,
        target_lang: str = 'hi'
    ) -> Dict:
        """
        Translate dosage instructions to patient's language
        
        Args:
            instructions: Dictionary with instruction fields
            target_lang: Target language code
        
        Returns:
            Translated instructions
        """
        translated = {}
        
        # Fields to translate
        fields_to_translate = [
            'drug_name',
            'dosage_instructions',
            'frequency_text',
            'special_instructions',
            'warnings'
        ]
        
        for field in fields_to_translate:
            if field in instructions and instructions[field]:
                result = self.translate_text(
                    instructions[field],
                    target_lang=target_lang
                )
                if result['success']:
                    translated[field] = result['translated']
                else:
                    translated[field] = instructions[field]  # Keep original if translation fails
        
        # Keep non-translatable fields as is
        for key, value in instructions.items():
            if key not in fields_to_translate:
                translated[key] = value
        
        translated['language'] = target_lang
        
        return translated
    
    def get_language_selector_html(self, current_lang: str = 'en') -> str:
        """
        Generate HTML for language selector dropdown
        
        Args:
            current_lang: Currently selected language code
        
        Returns:
            HTML string for language selector
        """
        html = ['<select id="languageSelector" class="form-select form-select-sm" style="width: auto;">']
        
        for code, name in self.SUPPORTED_LANGUAGES.items():
            selected = 'selected' if code == current_lang else ''
            html.append(f'<option value="{code}" {selected}>{name}</option>')
        
        html.append('</select>')
        
        return '\n'.join(html)
    
    def translate_common_medical_terms(self, target_lang: str = 'hi') -> Dict:
        """
        Pre-translate common medical terms for UI
        
        Args:
            target_lang: Target language code
        
        Returns:
            Dictionary of translated terms
        """
        common_terms = {
            'patient_name': 'Patient Name',
            'age': 'Age',
            'gender': 'Gender',
            'symptoms': 'Symptoms',
            'diagnosis': 'Diagnosis',
            'prescription': 'Prescription',
            'drug_name': 'Medicine Name',
            'dosage': 'Dosage',
            'frequency': 'Frequency',
            'duration': 'Duration',
            'instructions': 'Instructions',
            'warnings': 'Warnings',
            'allergies': 'Allergies',
            'medical_history': 'Medical History',
            'blood_pressure': 'Blood Pressure',
            'temperature': 'Temperature',
            'take_with_food': 'Take with food',
            'take_before_meals': 'Take before meals',
            'take_after_meals': 'Take after meals',
            'once_daily': 'Once daily',
            'twice_daily': 'Twice daily',
            'three_times_daily': 'Three times daily',
            'morning': 'Morning',
            'afternoon': 'Afternoon',
            'evening': 'Evening',
            'night': 'Night',
            'consultation_required': 'Consultation Required',
            'emergency': 'Emergency'
        }
        
        translated_terms = {}
        
        for key, english_text in common_terms.items():
            result = self.translate_text(english_text, target_lang=target_lang)
            if result['success']:
                translated_terms[key] = result['translated']
            else:
                translated_terms[key] = english_text
        
        return translated_terms
    
    @staticmethod
    def get_supported_languages() -> Dict:
        """Get list of supported languages"""
        return SimpleTranslator.SUPPORTED_LANGUAGES


# JavaScript code for frontend translation
TRANSLATION_JS = """
<script>
// Simple Translation System for Frontend
const translationCache = {};
let currentLanguage = 'en';

// Initialize language selector
document.addEventListener('DOMContentLoaded', function() {
    const langSelector = document.getElementById('languageSelector');
    if (langSelector) {
        langSelector.addEventListener('change', function() {
            changeLanguage(this.value);
        });
        
        // Load saved language preference
        const savedLang = localStorage.getItem('preferredLanguage');
        if (savedLang && savedLang !== 'en') {
            langSelector.value = savedLang;
            changeLanguage(savedLang);
        }
    }
});

// Change language function
async function changeLanguage(targetLang) {
    if (targetLang === 'en') {
        location.reload(); // Reload to show English
        return;
    }
    
    currentLanguage = targetLang;
    localStorage.setItem('preferredLanguage', targetLang);
    
    // Get all translatable elements
    const elements = document.querySelectorAll('[data-translate]');
    
    // Show loading indicator
    showTranslationLoading();
    
    try {
        // Translate each element
        for (const element of elements) {
            const originalText = element.getAttribute('data-original') || element.textContent;
            element.setAttribute('data-original', originalText);
            
            // Check cache first
            const cacheKey = `${targetLang}:${originalText}`;
            if (translationCache[cacheKey]) {
                element.textContent = translationCache[cacheKey];
                continue;
            }
            
            // Call translation API
            const translated = await translateText(originalText, targetLang);
            if (translated) {
                element.textContent = translated;
                translationCache[cacheKey] = translated;
            }
        }
        
        showAlert('Language changed successfully', 'success');
    } catch (error) {
        console.error('Translation error:', error);
        showAlert('Translation failed. Showing English.', 'warning');
    } finally {
        hideTranslationLoading();
    }
}

// API call to translate text
async function translateText(text, targetLang) {
    try {
        const response = await fetch('/api/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: text,
                target_lang: targetLang
            })
        });
        
        const result = await response.json();
        return result.success ? result.translated : text;
    } catch (error) {
        console.error('Translation API error:', error);
        return text;
    }
}

function showTranslationLoading() {
    const loader = document.createElement('div');
    loader.id = 'translationLoader';
    loader.className = 'alert alert-info position-fixed top-0 start-50 translate-middle-x mt-3';
    loader.style.zIndex = '9999';
    loader.innerHTML = '🌐 Translating...';
    document.body.appendChild(loader);
}

function hideTranslationLoading() {
    const loader = document.getElementById('translationLoader');
    if (loader) loader.remove();
}
</script>
"""


# Flask route handler for translation API
def create_translation_api_route(app, translator):
    """
    Add translation API endpoint to Flask app
    
    Usage:
        from simple_translator import SimpleTranslator, create_translation_api_route
        translator = SimpleTranslator()
        create_translation_api_route(app, translator)
    """
    from flask import request, jsonify
    
    @app.route('/api/translate', methods=['POST'])
    def translate_api():
        """API endpoint for text translation"""
        try:
            data = request.get_json()
            text = data.get('text', '')
            target_lang = data.get('target_lang', 'hi')
            
            if not text:
                return jsonify({
                    'success': False,
                    'error': 'No text provided'
                }), 400
            
            result = translator.translate_text(text, target_lang=target_lang)
            return jsonify(result)
        
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500


# Convenience functions
def translate(text: str, to_lang: str = 'hi') -> str:
    """Quick translate function"""
    translator = SimpleTranslator()
    result = translator.translate_text(text, target_lang=to_lang)
    return result['translated'] if result['success'] else text


def get_language_dropdown(current_lang: str = 'en') -> str:
    """Get language selector HTML"""
    translator = SimpleTranslator()
    return translator.get_language_selector_html(current_lang)