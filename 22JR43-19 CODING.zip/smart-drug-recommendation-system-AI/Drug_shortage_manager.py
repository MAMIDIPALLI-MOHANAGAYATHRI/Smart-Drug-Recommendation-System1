"""
Drug Shortage Manager & Alternative Suggester
Helps find therapeutic alternatives when drugs are out of stock
"""

from typing import List, Dict, Optional
from datetime import datetime
import json


class DrugShortageManager:
    """Manage drug shortages and suggest alternatives"""
    
    @staticmethod
    def find_therapeutic_alternatives(
        db,
        Drug,
        original_drug_name: str,
        patient_data: Dict = None
    ) -> List[Dict]:
        """
        Find therapeutic alternatives for a drug
        
        Strategy:
        1. Same generic name (different brands)
        2. Same drug class (therapeutic equivalents)
        3. Same category with similar mechanism
        
        Args:
            db: Database session
            Drug: Drug model class
            original_drug_name: Name of the drug to find alternatives for
            patient_data: Optional patient data for safety filtering
        
        Returns:
            List of alternative drugs with scores
        """
        alternatives = []
        
        # Get original drug
        original = Drug.query.filter(Drug.drug_name.ilike(original_drug_name)).first()
        
        if not original:
            return []
        
        # Strategy 1: Same generic name (different brands)
        if original.generic_name:
            same_generic = Drug.query.filter(
                Drug.generic_name == original.generic_name,
                Drug.id != original.id,
                Drug.in_stock == True
            ).all()
            
            for drug in same_generic:
                alternatives.append({
                    'drug': drug,
                    'match_type': 'same_generic',
                    'match_score': 100,
                    'reason': f'Same active ingredient ({original.generic_name})',
                    'equivalent': True
                })
        
        # Strategy 2: Same drug class
        if original.drug_class:
            same_class = Drug.query.filter(
                Drug.drug_class == original.drug_class,
                Drug.id != original.id,
                Drug.in_stock == True
            ).limit(5).all()
            
            for drug in same_class:
                # Skip if already added as same generic
                if drug.id not in [alt['drug'].id for alt in alternatives]:
                    alternatives.append({
                        'drug': drug,
                        'match_type': 'same_class',
                        'match_score': 85,
                        'reason': f'Same drug class ({original.drug_class})',
                        'equivalent': True
                    })
        
        # Strategy 3: Same category
        same_category = Drug.query.filter(
            Drug.category == original.category,
            Drug.id != original.id,
            Drug.in_stock == True
        ).limit(10).all()
        
        for drug in same_category:
            # Skip if already added
            if drug.id not in [alt['drug'].id for alt in alternatives]:
                alternatives.append({
                    'drug': drug,
                    'match_type': 'same_category',
                    'match_score': 70,
                    'reason': f'Same category ({original.category})',
                    'equivalent': False
                })
        
        # Strategy 4: Similar mechanism of action (keyword matching)
        if original.mechanism_of_action:
            # Simple keyword matching (can be enhanced with NLP)
            keywords = set(original.mechanism_of_action.lower().split())
            
            similar_moa = Drug.query.filter(
                Drug.category == original.category,
                Drug.id != original.id,
                Drug.in_stock == True
            ).all()
            
            for drug in similar_moa:
                if drug.id not in [alt['drug'].id for alt in alternatives]:
                    if drug.mechanism_of_action:
                        drug_keywords = set(drug.mechanism_of_action.lower().split())
                        overlap = len(keywords & drug_keywords)
                        
                        if overlap >= 2:  # At least 2 common keywords
                            alternatives.append({
                                'drug': drug,
                                'match_type': 'similar_mechanism',
                                'match_score': 60,
                                'reason': 'Similar mechanism of action',
                                'equivalent': False
                            })
        
        # Sort by match score (highest first)
        alternatives.sort(key=lambda x: x['match_score'], reverse=True)
        
        # Filter for patient safety if patient_data provided
        if patient_data:
            alternatives = DrugShortageManager._filter_safe_alternatives(
                alternatives, patient_data
            )
        
        return alternatives[:10]  # Return top 10
    
    @staticmethod
    def _filter_safe_alternatives(
        alternatives: List[Dict],
        patient_data: Dict
    ) -> List[Dict]:
        """Filter alternatives based on patient safety"""
        safe_alternatives = []
        
        age = patient_data.get('age', 0)
        allergies = patient_data.get('allergies', '').lower()
        is_pregnant = patient_data.get('is_pregnant', 'no') == 'yes'
        creatinine = patient_data.get('creatinine', 0)
        liver_enzyme = patient_data.get('liver_enzyme', 0)
        
        for alt in alternatives:
            drug = alt['drug']
            is_safe = True
            warnings = []
            
            # Age check
            if age < drug.age_min or age > drug.age_max:
                warnings.append(f'Age restriction ({drug.age_min}-{drug.age_max} years)')
                is_safe = False
            
            # Allergy check (basic)
            if allergies:
                allergy_list = [a.strip() for a in allergies.split(',')]
                for allergy in allergy_list:
                    if allergy in drug.drug_name.lower() or \
                       (drug.generic_name and allergy in drug.generic_name.lower()):
                        warnings.append(f'Patient allergic to {allergy}')
                        is_safe = False
            
            # Pregnancy check
            if is_pregnant and drug.pregnancy_safe == 'NO':
                warnings.append('Not safe during pregnancy')
                is_safe = False
            
            # Kidney check
            if drug.kidney_safe == 'NO' and creatinine and creatinine > 1.5:
                warnings.append('Requires renal dose adjustment')
            
            # Liver check
            if drug.liver_safe == 'NO' and liver_enzyme and liver_enzyme > 40:
                warnings.append('Requires hepatic dose adjustment')
            
            if is_safe:
                alt['warnings'] = warnings
                safe_alternatives.append(alt)
        
        return safe_alternatives
    
    @staticmethod
    def mark_drug_shortage(
        db,
        Drug,
        DrugShortageAlert,
        drug_id: int,
        severity: str,
        reason: str,
        estimated_availability: Optional[str] = None
    ) -> Dict:
        """
        Mark a drug as out of stock and create shortage alert
        
        Args:
            drug_id: ID of the drug
            severity: CRITICAL, HIGH, MEDIUM, LOW
            reason: Reason for shortage
            estimated_availability: Expected date when available
        
        Returns:
            Result dictionary
        """
        try:
            # Get drug
            drug = Drug.query.get(drug_id)
            if not drug:
                return {'success': False, 'error': 'Drug not found'}
            
            # Update drug stock status
            drug.in_stock = False
            drug.stock_level = 0
            drug.shortage_reason = reason
            drug.last_stock_update = datetime.utcnow()
            
            # Find alternatives
            alternatives = DrugShortageManager.find_therapeutic_alternatives(
                db, Drug, drug.drug_name
            )
            
            # Store alternative drug IDs
            alt_ids = [alt['drug'].id for alt in alternatives[:5]]
            drug.alternative_drugs = json.dumps(alt_ids)
            
            # Create shortage alert
            alert = DrugShortageAlert(
                drug_id=drug_id,
                severity=severity,
                reason=reason,
                estimated_availability_date=estimated_availability
            )
            
            db.session.add(alert)
            db.session.commit()
            
            return {
                'success': True,
                'drug_name': drug.drug_name,
                'alternatives_found': len(alternatives),
                'alert_id': alert.id
            }
        
        except Exception as e:
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def resolve_drug_shortage(
        db,
        Drug,
        DrugShortageAlert,
        drug_id: int,
        stock_level: int = 100
    ) -> Dict:
        """
        Mark drug as back in stock
        
        Args:
            drug_id: ID of the drug
            stock_level: Stock level percentage (default 100)
        
        Returns:
            Result dictionary
        """
        try:
            drug = Drug.query.get(drug_id)
            if not drug:
                return {'success': False, 'error': 'Drug not found'}
            
            # Update drug
            drug.in_stock = True
            drug.stock_level = stock_level
            drug.shortage_reason = None
            drug.last_stock_update = datetime.utcnow()
            
            # Resolve all active alerts
            alerts = DrugShortageAlert.query.filter_by(
                drug_id=drug_id,
                status='active'
            ).all()
            
            for alert in alerts:
                alert.status = 'resolved'
                alert.resolved_at = datetime.utcnow()
            
            db.session.commit()
            
            return {
                'success': True,
                'drug_name': drug.drug_name,
                'alerts_resolved': len(alerts)
            }
        
        except Exception as e:
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def get_shortage_summary(db, Drug, DrugShortageAlert) -> Dict:
        """Get summary of current drug shortages"""
        
        # Count by severity
        critical = DrugShortageAlert.query.filter_by(
            severity='CRITICAL',
            status='active'
        ).count()
        
        high = DrugShortageAlert.query.filter_by(
            severity='HIGH',
            status='active'
        ).count()
        
        medium = DrugShortageAlert.query.filter_by(
            severity='MEDIUM',
            status='active'
        ).count()
        
        # Get out of stock drugs
        out_of_stock = Drug.query.filter_by(in_stock=False).count()
        
        # Get low stock drugs (< 25%)
        low_stock = Drug.query.filter(
            Drug.in_stock == True,
            Drug.stock_level < 25
        ).count()
        
        return {
            'total_shortages': critical + high + medium,
            'critical_shortages': critical,
            'high_shortages': high,
            'medium_shortages': medium,
            'out_of_stock_count': out_of_stock,
            'low_stock_count': low_stock
        }
    
    @staticmethod
    def compare_alternatives(
        alternatives: List[Dict],
        comparison_factors: List[str] = None
    ) -> Dict:
        """
        Compare alternative drugs on multiple factors
        
        Args:
            alternatives: List of alternative drug dictionaries
            comparison_factors: Factors to compare ['price', 'efficacy', 'side_effects']
        
        Returns:
            Comparison table
        """
        if not comparison_factors:
            comparison_factors = ['price', 'category', 'dosage_forms']
        
        comparison = {
            'factors': comparison_factors,
            'drugs': []
        }
        
        for alt in alternatives:
            drug = alt['drug']
            drug_comparison = {
                'name': drug.drug_name,
                'match_score': alt['match_score'],
                'match_type': alt['match_type'],
                'reason': alt['reason']
            }
            
            # Add comparison factors
            if 'price' in comparison_factors:
                drug_comparison['price'] = f"₹{drug.price:.2f}" if drug.price else 'N/A'
            
            if 'category' in comparison_factors:
                drug_comparison['category'] = drug.category
            
            if 'dosage_forms' in comparison_factors:
                drug_comparison['dosage_forms'] = drug.dosage_forms
            
            if 'prescription_required' in comparison_factors:
                drug_comparison['prescription_required'] = 'Yes' if drug.prescription_required else 'No'
            
            comparison['drugs'].append(drug_comparison)
        
        return comparison


# Convenience functions
def get_alternatives(db, Drug, drug_name: str, patient_data: Dict = None) -> List[Dict]:
    """Get alternatives for a drug"""
    return DrugShortageManager.find_therapeutic_alternatives(
        db, Drug, drug_name, patient_data
    )


def check_drug_availability(db, Drug, drug_name: str) -> Dict:
    """Check if drug is available"""
    drug = Drug.query.filter(Drug.drug_name.ilike(drug_name)).first()
    
    if not drug:
        return {'available': False, 'error': 'Drug not found'}
    
    return {
        'available': drug.in_stock,
        'stock_level': drug.stock_level,
        'shortage_reason': drug.shortage_reason,
        'has_alternatives': bool(drug.alternative_drugs)
    }