from app import app, db
from models import Drug, Patient, Prescription, LabReport, DrugShortageAlert

with app.app_context():
    # Drop old database
    db.drop_all()
    print("✓ Dropped old database")
    
    # Create new database with all columns
    db.create_all()
    print("✓ Created new database with enhanced columns")
    
    print("\nDone! Now run: python app.py")