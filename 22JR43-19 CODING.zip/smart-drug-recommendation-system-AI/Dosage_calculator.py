"""
Dosage Calculator Module
Calculate accurate drug dosages based on patient parameters
"""

import math
import re
from typing import Dict, Optional, Tuple


class DosageCalculator:
    """Calculate drug dosages with safety checks"""
    
    @staticmethod
    def calculate_bsa(weight_kg: float, height_cm: float) -> float:
        """
        Calculate Body Surface Area using Mosteller formula
        BSA (m²) = √[(height(cm) × weight(kg)) / 3600]
        """
        if not weight_kg or not height_cm:
            return 0.0
        
        bsa = math.sqrt((height_cm * weight_kg) / 3600)
        return round(bsa, 2)
    
    @staticmethod
    def calculate_weight_based_dose(
        dose_per_kg: str,
        weight_kg: float,
        frequency_per_day: int = 1
    ) -> Dict:
        """
        Calculate dose based on weight
        
        Args:
            dose_per_kg: e.g., "10-15 mg/kg/day" or "5 mg/kg"
            weight_kg: Patient weight in kg
            frequency_per_day: How many times per day
        
        Returns:
            Dictionary with min_dose, max_dose, per_dose
        """
        try:
            # Extract numbers from dose_per_kg
            numbers = re.findall(r'\d+(?:\.\d+)?', dose_per_kg)
            
            if not numbers or not weight_kg:
                return {
                    'success': False,
                    'error': 'Invalid dose or weight'
                }
            
            # Parse dose range
            if len(numbers) >= 2:
                min_dose_per_kg = float(numbers[0])
                max_dose_per_kg = float(numbers[1])
            else:
                min_dose_per_kg = max_dose_per_kg = float(numbers[0])
            
            # Calculate total daily dose
            min_total_dose = min_dose_per_kg * weight_kg
            max_total_dose = max_dose_per_kg * weight_kg
            
            # Calculate per-dose (divided by frequency)
            min_per_dose = min_total_dose / frequency_per_day
            max_per_dose = max_total_dose / frequency_per_day
            
            # Extract unit (mg, mcg, etc.)
            unit_match = re.search(r'(mg|mcg|g|ml)', dose_per_kg.lower())
            unit = unit_match.group(1) if unit_match else 'mg'
            
            return {
                'success': True,
                'min_total_daily_dose': round(min_total_dose, 2),
                'max_total_daily_dose': round(max_total_dose, 2),
                'min_per_dose': round(min_per_dose, 2),
                'max_per_dose': round(max_per_dose, 2),
                'unit': unit,
                'frequency_per_day': frequency_per_day,
                'calculation_note': f"Based on {dose_per_kg} for {weight_kg} kg patient"
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def adjust_for_renal_function(
        standard_dose: float,
        creatinine: float,
        age: int,
        weight_kg: float,
        gender: str
    ) -> Dict:
        """
        Calculate renal dose adjustment using Cockcroft-Gault formula
        
        CrCl (ml/min) = [(140 - age) × weight(kg)] / (72 × Creatinine(mg/dL))
        For females: multiply by 0.85
        
        Dose adjustments:
        - CrCl > 50: 100% dose
        - CrCl 30-50: 75% dose
        - CrCl 10-30: 50% dose
        - CrCl < 10: 25% dose
        """
        try:
            if not creatinine or creatinine <= 0:
                return {
                    'success': False,
                    'error': 'Invalid creatinine value'
                }
            
            # Calculate Creatinine Clearance (CrCl)
            crcl = ((140 - age) * weight_kg) / (72 * creatinine)
            
            if gender.lower() == 'female':
                crcl *= 0.85
            
            crcl = round(crcl, 2)
            
            # Determine dose adjustment
            if crcl > 50:
                adjustment_factor = 1.0
                recommendation = "No dose adjustment needed"
                severity = "normal"
            elif crcl >= 30:
                adjustment_factor = 0.75
                recommendation = "Reduce dose to 75% of standard dose"
                severity = "mild_impairment"
            elif crcl >= 10:
                adjustment_factor = 0.50
                recommendation = "Reduce dose to 50% of standard dose"
                severity = "moderate_impairment"
            else:
                adjustment_factor = 0.25
                recommendation = "Reduce dose to 25% of standard dose - Consult nephrologist"
                severity = "severe_impairment"
            
            adjusted_dose = round(standard_dose * adjustment_factor, 2)
            
            return {
                'success': True,
                'creatinine_clearance': crcl,
                'adjustment_factor': adjustment_factor,
                'adjusted_dose': adjusted_dose,
                'recommendation': recommendation,
                'severity': severity,
                'warning': severity in ['moderate_impairment', 'severe_impairment']
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def adjust_for_hepatic_function(
        standard_dose: float,
        liver_enzyme: float
    ) -> Dict:
        """
        Hepatic dose adjustment based on liver enzyme levels
        
        Normal ALT/AST: < 40 U/L
        Mild: 40-100 U/L (75% dose)
        Moderate: 100-200 U/L (50% dose)
        Severe: > 200 U/L (25% dose)
        """
        try:
            if not liver_enzyme or liver_enzyme <= 0:
                return {
                    'success': False,
                    'error': 'Invalid liver enzyme value'
                }
            
            if liver_enzyme < 40:
                adjustment_factor = 1.0
                recommendation = "No dose adjustment needed"
                severity = "normal"
            elif liver_enzyme < 100:
                adjustment_factor = 0.75
                recommendation = "Reduce dose to 75% - Mild hepatic impairment"
                severity = "mild_impairment"
            elif liver_enzyme < 200:
                adjustment_factor = 0.50
                recommendation = "Reduce dose to 50% - Moderate hepatic impairment"
                severity = "moderate_impairment"
            else:
                adjustment_factor = 0.25
                recommendation = "Reduce dose to 25% - Severe hepatic impairment - Consult hepatologist"
                severity = "severe_impairment"
            
            adjusted_dose = round(standard_dose * adjustment_factor, 2)
            
            return {
                'success': True,
                'liver_enzyme_level': liver_enzyme,
                'adjustment_factor': adjustment_factor,
                'adjusted_dose': adjusted_dose,
                'recommendation': recommendation,
                'severity': severity,
                'warning': severity in ['moderate_impairment', 'severe_impairment']
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def get_pediatric_dose(
        adult_dose: float,
        age: int,
        weight_kg: float
    ) -> Dict:
        """
        Calculate pediatric dose using Young's Rule and Clark's Rule
        
        Young's Rule: [Age / (Age + 12)] × Adult Dose
        Clark's Rule: [Weight(kg) / 70] × Adult Dose
        """
        try:
            # Young's Rule (age-based)
            youngs_dose = (age / (age + 12)) * adult_dose
            
            # Clark's Rule (weight-based)
            clarks_dose = (weight_kg / 70) * adult_dose
            
            # Use the more conservative (lower) dose
            recommended_dose = min(youngs_dose, clarks_dose)
            
            return {
                'success': True,
                'youngs_rule_dose': round(youngs_dose, 2),
                'clarks_rule_dose': round(clarks_dose, 2),
                'recommended_dose': round(recommended_dose, 2),
                'note': 'Using the more conservative calculation'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def generate_dosage_instructions(
        drug_name: str,
        calculated_dose: float,
        frequency: str,
        duration: str,
        take_with_food: str,
        special_instructions: str = None
    ) -> str:
        """
        Generate clear, patient-friendly dosage instructions
        """
        instructions = []
        
        # Main instruction
        instructions.append(f"💊 **{drug_name}** - {calculated_dose} mg")
        
        # Frequency
        freq_map = {
            'OD': 'once daily',
            'BD': 'twice daily',
            'TDS': 'three times daily',
            'QID': 'four times daily',
            'Q4H': 'every 4 hours',
            'Q6H': 'every 6 hours',
            'Q8H': 'every 8 hours',
            'Q12H': 'every 12 hours',
            'PRN': 'as needed'
        }
        freq_text = freq_map.get(frequency.upper(), frequency)
        instructions.append(f"📅 Take {freq_text}")
        
        # Duration
        if duration:
            instructions.append(f"⏱️ For {duration}")
        
        # Food instructions
        food_instructions = {
            'YES': '🍽️ Take WITH food or milk',
            'NO': '⚠️ Take on EMPTY stomach (1 hour before or 2 hours after meals)',
            'EITHER': '🍽️ Can be taken with or without food'
        }
        if take_with_food and take_with_food.upper() in food_instructions:
            instructions.append(food_instructions[take_with_food.upper()])
        
        # Special instructions
        if special_instructions:
            instructions.append(f"ℹ️ {special_instructions}")
        
        # General reminders
        instructions.append("\n⚠️ Important Reminders:")
        instructions.append("• Take at the same time each day")
        instructions.append("• Complete the full course even if you feel better")
        instructions.append("• Do not double dose if you miss one")
        instructions.append("• Store as per package instructions")
        
        return "\n".join(instructions)
    
    @staticmethod
    def comprehensive_dose_calculation(
        drug_data: Dict,
        patient_data: Dict
    ) -> Dict:
        """
        Perform comprehensive dosage calculation considering all factors
        
        Args:
            drug_data: Dictionary with drug information
            patient_data: Dictionary with patient information
        
        Returns:
            Comprehensive dosage calculation result
        """
        result = {
            'success': True,
            'calculations': {},
            'final_dose': None,
            'warnings': [],
            'instructions': ''
        }
        
        try:
            # Extract patient data
            age = patient_data.get('age', 0)
            weight_kg = patient_data.get('weight_kg', 0)
            height_cm = patient_data.get('height_cm', 0)
            gender = patient_data.get('gender', '')
            creatinine = patient_data.get('creatinine', 0)
            liver_enzyme = patient_data.get('liver_enzyme', 0)
            
            # Extract drug data
            weight_based_dosing = drug_data.get('weight_based_dosing', False)
            dose_per_kg = drug_data.get('dose_per_kg', '')
            standard_dosage = drug_data.get('standard_dosage', '')
            kidney_safe = drug_data.get('kidney_safe', 'YES')
            liver_safe = drug_data.get('liver_safe', 'YES')
            
            # Calculate BSA if height and weight available
            if weight_kg and height_cm:
                result['calculations']['bsa'] = DosageCalculator.calculate_bsa(weight_kg, height_cm)
            
            # Weight-based dosing
            if weight_based_dosing and dose_per_kg and weight_kg:
                dose_calc = DosageCalculator.calculate_weight_based_dose(dose_per_kg, weight_kg)
                result['calculations']['weight_based'] = dose_calc
                
                if dose_calc['success']:
                    base_dose = dose_calc['max_per_dose']
                else:
                    base_dose = 0
            else:
                # Extract standard dose number
                dose_numbers = re.findall(r'\d+(?:\.\d+)?', standard_dosage)
                base_dose = float(dose_numbers[0]) if dose_numbers else 0
            
            # Renal adjustment
            if kidney_safe == 'NO' and creatinine and creatinine > 0:
                renal_adj = DosageCalculator.adjust_for_renal_function(
                    base_dose, creatinine, age, weight_kg or 70, gender
                )
                result['calculations']['renal_adjustment'] = renal_adj
                
                if renal_adj['success'] and renal_adj.get('warning'):
                    result['warnings'].append(renal_adj['recommendation'])
                    base_dose = renal_adj['adjusted_dose']
            
            # Hepatic adjustment
            if liver_safe == 'NO' and liver_enzyme and liver_enzyme > 0:
                hepatic_adj = DosageCalculator.adjust_for_hepatic_function(
                    base_dose, liver_enzyme
                )
                result['calculations']['hepatic_adjustment'] = hepatic_adj
                
                if hepatic_adj['success'] and hepatic_adj.get('warning'):
                    result['warnings'].append(hepatic_adj['recommendation'])
                    base_dose = hepatic_adj['adjusted_dose']
            
            # Pediatric adjustment (if age < 18)
            if age < 18 and age > 0:
                pediatric = DosageCalculator.get_pediatric_dose(base_dose, age, weight_kg or 30)
                result['calculations']['pediatric_adjustment'] = pediatric
                
                if pediatric['success']:
                    base_dose = pediatric['recommended_dose']
                    result['warnings'].append("Pediatric dose calculated - Verify with pediatrician")
            
            # Final dose
            result['final_dose'] = round(base_dose, 2)
            
            # Generate instructions
            result['instructions'] = DosageCalculator.generate_dosage_instructions(
                drug_name=drug_data.get('drug_name', ''),
                calculated_dose=result['final_dose'],
                frequency=patient_data.get('frequency', 'BD'),
                duration=patient_data.get('duration', '7 days'),
                take_with_food=drug_data.get('take_with_food', 'EITHER'),
                special_instructions=drug_data.get('special_instructions')
            )
            
            return result
        
        except Exception as e:
            result['success'] = False
            result['error'] = str(e)
            return result


# Utility functions for easy access
def calculate_dose(drug_data: Dict, patient_data: Dict) -> Dict:
    """Convenience function for dosage calculation"""
    return DosageCalculator.comprehensive_dose_calculation(drug_data, patient_data)


def format_dosage_display(calculation_result: Dict) -> str:
    """Format calculation result for display"""
    if not calculation_result['success']:
        return f"Error: {calculation_result.get('error', 'Unknown error')}"
    
    output = []
    output.append(f"**Calculated Dose: {calculation_result['final_dose']} mg**\n")
    
    if calculation_result.get('warnings'):
        output.append("⚠️ **Warnings:**")
        for warning in calculation_result['warnings']:
            output.append(f"  • {warning}")
        output.append("")
    
    output.append("**Dosage Instructions:**")
    output.append(calculation_result['instructions'])
    
    return "\n".join(output)