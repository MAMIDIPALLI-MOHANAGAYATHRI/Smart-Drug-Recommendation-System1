/**
 * Enhanced Features JavaScript
 * Utilities for dosage calculator, OCR, alternatives, translation
 * SmartRx v4.0
 */

// ============================================================================
// DOSAGE CALCULATOR
// ============================================================================

class DosageCalculator {
    static async calculate(drugName, patientId, frequency = 'BD', duration = '7 days') {
        try {
            const response = await fetch('/api/calculate-dosage', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    drug_name: drugName,
                    patient_id: patientId,
                    frequency: frequency,
                    duration: duration
                })
            });
            
            if (!response.ok) throw new Error('API request failed');
            return await response.json();
        } catch (error) {
            console.error('Dosage calculation error:', error);
            return {success: false, error: error.message};
        }
    }
    
    static displayResult(result, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (!result.success) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>${result.error}
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="dosage-result mb-3">
                <i class="fas fa-pills me-2"></i>${result.final_dose} mg
            </div>
            ${result.warnings && result.warnings.length > 0 ? `
                <div class="alert alert-warning mb-3">
                    <strong><i class="fas fa-exclamation-triangle me-2"></i>Warnings:</strong><br>
                    ${result.warnings.join('<br>')}
                </div>
            ` : ''}
            <div class="card bg-light">
                <div class="card-body">
                    <h6 class="text-primary mb-2">
                        <i class="fas fa-info-circle me-2"></i>Instructions:
                    </h6>
                    <pre style="white-space: pre-wrap; font-size: 0.9em;">${result.instructions}</pre>
                </div>
            </div>
        `;
    }
}


// ============================================================================
// DRUG ALTERNATIVES FINDER
// ============================================================================

class AlternativesFinder {
    static async find(drugName, patientId = null) {
        try {
            let url = `/api/drug-alternatives/${encodeURIComponent(drugName)}`;
            if (patientId) url += `?patient_id=${patientId}`;
            
            const response = await fetch(url);
            if (!response.ok) throw new Error('API request failed');
            return await response.json();
        } catch (error) {
            console.error('Alternatives finder error:', error);
            return {success: false, error: error.message, alternatives: []};
        }
    }
    
    static displayAlternatives(alternatives, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (!alternatives || alternatives.length === 0) {
            container.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>No alternatives found
                </div>
            `;
            return;
        }
        
        let html = '<div class="row">';
        alternatives.forEach((alt, index) => {
            const matchClass = alt.match_score >= 90 ? 'success' : alt.match_score >= 75 ? 'primary' : 'info';
            const equivBadge = alt.equivalent ? '<span class="badge bg-success ms-2">Equivalent</span>' : '';
            
            html += `
                <div class="col-md-6 mb-3">
                    <div class="card alternative-card border-${matchClass}">
                        <div class="card-body">
                            <h6 class="card-title">
                                ${index + 1}. ${alt.drug_name} ${equivBadge}
                            </h6>
                            <div class="progress match-score-bar mb-2">
                                <div class="progress-bar bg-${matchClass}" 
                                     style="width: ${alt.match_score}%"></div>
                            </div>
                            <small class="text-muted d-block mb-1">
                                <strong>Match:</strong> ${alt.match_score}% - ${alt.reason}
                            </small>
                            <small class="text-muted d-block mb-1">
                                <strong>Category:</strong> ${alt.category}
                            </small>
                            <small class="text-muted d-block">
                                <strong>Price:</strong> ₹${alt.price || 'N/A'}
                            </small>
                            ${alt.in_stock ? 
                                '<span class="badge bg-success mt-2">In Stock</span>' : 
                                '<span class="badge bg-danger mt-2">Out of Stock</span>'
                            }
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    }
}


// ============================================================================
// LAB REPORT OCR
// ============================================================================

class LabReportOCR {
    static async upload(file, patientId) {
        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('patient_id', patientId);
            
            const response = await fetch('/api/upload-lab-report', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) throw new Error('Upload failed');
            return await response.json();
        } catch (error) {
            console.error('OCR upload error:', error);
            return {success: false, error: error.message};
        }
    }
    
    static applyToForm(extractedValues) {
        let appliedCount = 0;
        
        for (const [key, value] of Object.entries(extractedValues)) {
            const field = document.getElementById(key);
            if (field) {
                field.value = value;
                field.classList.add('border-success');
                
                // Visual feedback
                field.style.transition = 'background-color 0.3s';
                field.style.backgroundColor = '#d4edda';
                setTimeout(() => {
                    field.style.backgroundColor = '';
                }, 1000);
                
                appliedCount++;
            }
        }
        
        return appliedCount;
    }
    
    static displayResults(result, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (!result.success) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>${result.error}
                </div>
            `;
            return;
        }
        
        const values = result.extracted_values || {};
        const flags = result.abnormal_flags || {};
        
        let html = '<div class="list-group">';
        
        for (const [key, value] of Object.entries(values)) {
            const flag = flags[key];
            const statusIcon = flag ? (flag.status === 'NORMAL' ? '✅' : flag.status === 'LOW' ? '⬇️' : '⬆️') : '📊';
            const itemClass = flag && flag.status !== 'NORMAL' ? 'list-group-item-warning' : '';
            
            html += `
                <div class="list-group-item ${itemClass}">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${statusIcon} ${key.replace(/_/g, ' ').toUpperCase()}:</strong>
                            <span class="ms-2">${value}</span>
                            ${flag ? `<small class="text-muted ms-2">(Normal: ${flag.normal_range} ${flag.unit})</small>` : ''}
                        </div>
                        ${flag && flag.status !== 'NORMAL' ? `<span class="badge bg-warning">${flag.status}</span>` : ''}
                    </div>
                </div>
            `;
        }
        
        html += '</div>';
        container.innerHTML = html;
    }
}


// ============================================================================
// TRANSLATION
// ============================================================================

class Translator {
    static currentLanguage = 'en';
    static cache = {};
    
    static async translate(text, targetLang) {
        if (!text || targetLang === 'en') return text;
        
        const cacheKey = `${targetLang}:${text}`;
        if (this.cache[cacheKey]) return this.cache[cacheKey];
        
        try {
            const response = await fetch('/api/translate', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    text: text,
                    target_lang: targetLang
                })
            });
            
            const result = await response.json();
            
            if (result.success && result.translated) {
                this.cache[cacheKey] = result.translated;
                return result.translated;
            }
        } catch (error) {
            console.error('Translation error:', error);
        }
        
        return text; // Return original if translation fails
    }
    
    static async translateElement(element, targetLang) {
        if (!element) return;
        
        const originalText = element.getAttribute('data-original') || element.textContent;
        element.setAttribute('data-original', originalText);
        
        const translated = await this.translate(originalText, targetLang);
        element.textContent = translated;
    }
    
    static async translatePage(targetLang) {
        this.currentLanguage = targetLang;
        
        const elements = document.querySelectorAll('[data-translate]');
        const promises = Array.from(elements).map(el => this.translateElement(el, targetLang));
        
        await Promise.all(promises);
    }
}


// ============================================================================
// NOTIFICATION SYSTEM
// ============================================================================

function showNotification(message, type = 'info', duration = 3000) {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alert.style.zIndex = '9999';
    alert.style.minWidth = '300px';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => alert.remove(), 300);
    }, duration);
}

function showLoading(message = 'Processing...') {
    const loader = document.createElement('div');
    loader.id = 'globalLoader';
    loader.className = 'position-fixed top-50 start-50 translate-middle';
    loader.style.zIndex = '10000';
    loader.innerHTML = `
        <div class="card shadow-lg">
            <div class="card-body text-center p-4">
                <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;"></div>
                <p class="mb-0">${message}</p>
            </div>
        </div>
    `;
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('globalLoader');
    if (loader) loader.remove();
}


// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

// Copy text to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Copied to clipboard!', 'success', 2000);
    }).catch(err => {
        showNotification('Copy failed', 'danger', 2000);
    });
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

// Validate lab value range
function validateLabValue(fieldName, value, gender = 'male') {
    const ranges = {
        hemoglobin: {
            male: {min: 13, max: 17, unit: 'g/dL'},
            female: {min: 12, max: 15, unit: 'g/dL'}
        },
        blood_sugar: {min: 70, max: 140, unit: 'mg/dL'},
        creatinine: {
            male: {min: 0.7, max: 1.3, unit: 'mg/dL'},
            female: {min: 0.6, max: 1.1, unit: 'mg/dL'}
        },
        liver_enzyme: {min: 0, max: 40, unit: 'U/L'}
    };
    
    const range = ranges[fieldName];
    if (!range) return null;
    
    const limits = range[gender] || range;
    
    if (value < limits.min) {
        return {status: 'LOW', color: 'warning', message: `Below normal (${limits.min}-${limits.max} ${limits.unit})`};
    } else if (value > limits.max) {
        return {status: 'HIGH', color: 'danger', message: `Above normal (${limits.min}-${limits.max} ${limits.unit})`};
    } else {
        return {status: 'NORMAL', color: 'success', message: `Normal (${limits.min}-${limits.max} ${limits.unit})`};
    }
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}


// ============================================================================
// EXPORT OBJECTS (for module usage)
// ============================================================================

window.SmartRx = {
    DosageCalculator,
    AlternativesFinder,
    LabReportOCR,
    Translator,
    showNotification,
    showLoading,
    hideLoading,
    copyToClipboard,
    formatCurrency,
    validateLabValue,
    debounce
};


// ============================================================================
// INITIALIZATION
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ SmartRx Enhanced Features v4.0 loaded');
    
    // Auto-validate lab value inputs
    const labFields = document.querySelectorAll('input[id^="hemoglobin"], input[id^="blood_sugar"], input[id^="creatinine"], input[id^="liver_enzyme"]');
    
    labFields.forEach(field => {
        field.addEventListener('input', debounce(function() {
            const value = parseFloat(this.value);
            if (value) {
                const fieldName = this.id;
                const gender = document.getElementById('gender')?.value.toLowerCase() || 'male';
                const validation = validateLabValue(fieldName, value, gender);
                
                if (validation) {
                    const statusElement = document.getElementById(fieldName + '_status');
                    if (statusElement) {
                        statusElement.innerHTML = `<span class="text-${validation.color}">${validation.status} - ${validation.message}</span>`;
                    }
                }
            }
        }, 500));
    });
});