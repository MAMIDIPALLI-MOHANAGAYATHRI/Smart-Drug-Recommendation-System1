/**
 * Drug Search Functionality
 * Simple autocomplete and search
 */

// This file is optional - your search already works!
// If you get 404 error, just create this empty file or add basic search function

console.log('✓ Drug search module loaded');

// Simple drug search helper
function searchDrugByName(drugName, callback) {
    fetch(`/search-drugs?q=${encodeURIComponent(drugName)}`)
        .then(response => response.json())
        .then(data => callback(data))
        .catch(error => console.error('Search error:', error));
}