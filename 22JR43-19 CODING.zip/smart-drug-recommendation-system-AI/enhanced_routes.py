"""
Enhanced Flask Routes - v4.0 Features
Routes for dosage calculator, drug shortage, lab OCR
"""

from flask import request, jsonify, render_template
from werkzeug.utils import secure_filename
import os
from datetime import datetime
import json

def register_enhanced_routes(app, db, models):
    """Register all enhanced routes"""
    
    Drug = models['Drug']
    Patient = models['Patient']
    Prescription = models['Prescription']
    LabReport = models['LabReport']
    DrugShortageAlert = models['DrugShortageAlert']
    PatientVisit = models['PatientVisit']
    
    # Import utility modules (with error handling)
    try:
        from Dosage_calculator import DosageCalculator
        HAS_DOSAGE_CALC = True
    except:
        HAS_DOSAGE_CALC = False
        print("⚠ Dosage calculator not available")
    
    try:
        from Drug_shortage_manager import DrugShortageManager
        HAS_SHORTAGE_MGR = True
    except:
        HAS_SHORTAGE_MGR = False
        print("⚠ Drug shortage manager not available")
    
    try:
        from Lab_report_ocr import LabReportOCR
        HAS_LAB_OCR = True
    except:
        HAS_LAB_OCR = False
        print("⚠ Lab OCR not available")
    
    
    # ========================================================================
    # DOSAGE CALCULATOR ROUTES
    # ========================================================================
    
    @app.route('/dosage-calculator')
    def dosage_calculator_page():
        """Dosage calculator page"""
        return render_template('dosage_calculator.html')
    
    @app.route('/api/calculate-dosage', methods=['POST'])
    def calculate_dosage_api():
        """Calculate drug dosage API"""
        if not HAS_DOSAGE_CALC:
            return jsonify({'success': False, 'error': 'Dosage calculator not available'}), 500
        
        try:
            data = request.get_json()
            drug_name = data.get('drug_name')
            patient_id = data.get('patient_id')
            
            if not drug_name or not patient_id:
                return jsonify({'success': False, 'error': 'Missing required fields'}), 400
            
            drug = Drug.query.filter(Drug.drug_name.ilike(drug_name)).first()
            if not drug:
                return jsonify({'success': False, 'error': 'Drug not found'}), 404
            
            patient = Patient.query.get(patient_id)
            if not patient:
                return jsonify({'success': False, 'error': 'Patient not found'}), 404
            
            # Prepare data
            drug_data = drug.to_dict()
            patient_data = patient.to_dict()
            patient_data['frequency'] = data.get('frequency', 'BD')
            patient_data['duration'] = data.get('duration', '7 days')
            
            # Get latest lab values
            latest_visit = patient.visits.order_by(PatientVisit.visit_date.desc()).first()
            if latest_visit:
                patient_data.update({
                    'creatinine': latest_visit.creatinine,
                    'liver_enzyme': latest_visit.liver_enzyme
                })
            
            # Calculate dosage
            from Dosage_calculator import calculate_dose, format_dosage_display
            calculation = calculate_dose(drug_data, patient_data)
            
            if calculation['success']:
                return jsonify({
                    'success': True,
                    'final_dose': calculation['final_dose'],
                    'instructions': calculation['instructions'],
                    'warnings': calculation.get('warnings', []),
                    'calculations': calculation.get('calculations', {}),
                    'formatted_display': format_dosage_display(calculation)
                })
            else:
                return jsonify({'success': False, 'error': calculation.get('error')}), 500
        
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    
    # ========================================================================
    # DRUG SHORTAGE ROUTES
    # ========================================================================
    
    @app.route('/shortage-dashboard')
    def shortage_dashboard():
        """Drug shortage dashboard"""
        if not HAS_SHORTAGE_MGR:
            return "Shortage manager not available", 500
        
        summary = DrugShortageManager.get_shortage_summary(db, Drug, DrugShortageAlert)
        out_of_stock = Drug.query.filter_by(in_stock=False).all()
        active_alerts = DrugShortageAlert.query.filter_by(status='active').all()
        
        return render_template('shortage_dashboard.html',
                             summary=summary,
                             out_of_stock=out_of_stock,
                             active_alerts=active_alerts)
    
    @app.route('/api/drug-alternatives/<drug_name>', methods=['GET'])
    def get_drug_alternatives(drug_name):
        """Get alternative drugs"""
        if not HAS_SHORTAGE_MGR:
            return jsonify({'success': False, 'error': 'Shortage manager not available'}), 500
        
        try:
            patient_id = request.args.get('patient_id', type=int)
            patient_data = None
            
            if patient_id:
                patient = Patient.query.get(patient_id)
                if patient:
                    patient_data = patient.to_dict()
            
            from Drug_shortage_manager import get_alternatives
            alternatives = get_alternatives(db, Drug, drug_name, patient_data)
            
            if not alternatives:
                return jsonify({'success': True, 'message': 'No alternatives found', 'alternatives': []})
            
            result = []
            for alt in alternatives:
                drug = alt['drug']
                result.append({
                    'drug_name': drug.drug_name,
                    'generic_name': drug.generic_name,
                    'category': drug.category,
                    'match_score': alt['match_score'],
                    'match_type': alt['match_type'],
                    'reason': alt['reason'],
                    'equivalent': alt['equivalent'],
                    'price': drug.price,
                    'in_stock': drug.in_stock,
                    'warnings': alt.get('warnings', [])
                })
            
            return jsonify({
                'success': True,
                'original_drug': drug_name,
                'alternatives_count': len(result),
                'alternatives': result
            })
        
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @app.route('/api/drug-shortage/mark', methods=['POST'])
    def mark_drug_shortage():
        """Mark drug as out of stock"""
        if not HAS_SHORTAGE_MGR:
            return jsonify({'success': False, 'error': 'Shortage manager not available'}), 500
        
        try:
            data = request.get_json()
            result = DrugShortageManager.mark_drug_shortage(
                db=db,
                Drug=Drug,
                DrugShortageAlert=DrugShortageAlert,
                drug_id=data.get('drug_id'),
                severity=data.get('severity', 'MEDIUM'),
                reason=data.get('reason', ''),
                estimated_availability=data.get('estimated_availability')
            )
            
            if result['success']:
                return jsonify(result)
            else:
                return jsonify(result), 400
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @app.route('/api/drug-shortage/resolve', methods=['POST'])
    def resolve_drug_shortage():
        """Mark drug as back in stock"""
        if not HAS_SHORTAGE_MGR:
            return jsonify({'success': False, 'error': 'Shortage manager not available'}), 500
        
        try:
            data = request.get_json()
            result = DrugShortageManager.resolve_drug_shortage(
                db=db,
                Drug=Drug,
                DrugShortageAlert=DrugShortageAlert,
                drug_id=data.get('drug_id'),
                stock_level=data.get('stock_level', 100)
            )
            return jsonify(result)
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    
    # ========================================================================
    # LAB REPORT OCR ROUTES
    # ========================================================================
    
    @app.route('/lab-report-upload')
    def lab_report_upload_page():
        """Lab report upload page"""
        patients = Patient.query.all()
        return render_template('lab_report_upload.html', patients=patients)
    
    @app.route('/api/upload-lab-report', methods=['POST'])
    def upload_lab_report():
        """Upload and process lab report"""
        if not HAS_LAB_OCR:
            return jsonify({'success': False, 'error': 'Lab OCR not available'}), 500
        
        try:
            if 'file' not in request.files:
                return jsonify({'success': False, 'error': 'No file uploaded'}), 400
            
            file = request.files['file']
            patient_id = request.form.get('patient_id', type=int)
            
            if not patient_id:
                return jsonify({'success': False, 'error': 'Patient ID required'}), 400
            
            if file.filename == '':
                return jsonify({'success': False, 'error': 'Empty filename'}), 400
            
            # Save file
            filename = secure_filename(file.filename)
            upload_folder = app.config.get('UPLOAD_FOLDER', 'uploads/lab_reports')
            os.makedirs(upload_folder, exist_ok=True)
            
            file_path = os.path.join(upload_folder, f"{patient_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}")
            file.save(file_path)
            
            # Get patient
            patient = Patient.query.get(patient_id)
            gender = patient.gender.lower() if patient else 'male'
            
            # Process with OCR
            from Lab_report_ocr import extract_lab_values_from_file, save_lab_report_to_db, LabReportOCR
            processing_result = extract_lab_values_from_file(file_path, gender)
            
            # Save to database
            save_result = save_lab_report_to_db(
                db=db,
                LabReport=LabReport,
                patient_id=patient_id,
                file_path=file_path,
                processing_result=processing_result
            )
            
            # Generate summary
            summary = LabReportOCR.generate_summary_report(processing_result)
            
            return jsonify({
                'success': True,
                'report_id': save_result.get('report_id'),
                'extracted_values': processing_result.get('extracted_values', {}),
                'abnormal_flags': processing_result.get('abnormal_flags', {}),
                'summary': summary,
                'ocr_confidence': processing_result.get('ocr_result', {}).get('confidence', 0)
            })
        
        except Exception as e:
            import traceback
            traceback.print_exc()
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @app.route('/lab-reports/<int:patient_id>')
    def view_lab_reports(patient_id):
        """View all lab reports for a patient"""
        patient = Patient.query.get_or_404(patient_id)
        reports = LabReport.query.filter_by(patient_id=patient_id).order_by(
            LabReport.uploaded_at.desc()
        ).all()
        
        return render_template('lab_reports.html', patient=patient, reports=reports)
    
    
    print("✅ Enhanced routes registered successfully")