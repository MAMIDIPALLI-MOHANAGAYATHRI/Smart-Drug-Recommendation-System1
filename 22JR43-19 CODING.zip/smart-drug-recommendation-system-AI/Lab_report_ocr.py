"""
Lab Report OCR Extractor
Automatically extract lab values from uploaded PDF/image reports
Uses pytesseract for OCR and regex pattern matching for value extraction
"""

import re
import os
from typing import Dict, Optional, List, Tuple
from datetime import datetime
import json

# OCR will need these libraries (add to requirements.txt):
# pytesseract
# pdf2image
# Pillow
# opencv-python

try:
    import pytesseract
    from PIL import Image
    import pdf2image
    HAS_OCR = True
except ImportError:
    HAS_OCR = False
    print("⚠️ OCR libraries not installed. Install with: pip install pytesseract pdf2image Pillow")


class LabReportOCR:
    """Extract lab values from medical reports"""
    
    # Common lab test patterns and their regex
    LAB_PATTERNS = {
        'hemoglobin': [
            r'h(?:ae|e)moglobin[:\s]*([0-9]+\.?[0-9]*)',
            r'hb[:\s]*([0-9]+\.?[0-9]*)',
            r'hgb[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'blood_sugar': [
            r'glucose[:\s]*([0-9]+\.?[0-9]*)',
            r'blood\s+sugar[:\s]*([0-9]+\.?[0-9]*)',
            r'fbs[:\s]*([0-9]+\.?[0-9]*)',  # Fasting blood sugar
            r'rbs[:\s]*([0-9]+\.?[0-9]*)',  # Random blood sugar
            r'ppbs[:\s]*([0-9]+\.?[0-9]*)', # Post-prandial blood sugar
        ],
        'creatinine': [
            r'creatinine[:\s]*([0-9]+\.?[0-9]*)',
            r'serum\s+creatinine[:\s]*([0-9]+\.?[0-9]*)',
            r's\.creatinine[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'liver_enzyme': [
            r'alt[:\s]*([0-9]+\.?[0-9]*)',
            r'sgpt[:\s]*([0-9]+\.?[0-9]*)',
            r'ast[:\s]*([0-9]+\.?[0-9]*)',
            r'sgot[:\s]*([0-9]+\.?[0-9]*)',
            r'liver\s+enzymes?[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'wbc_count': [
            r'wbc[:\s]*([0-9]+\.?[0-9]*)',
            r'white\s+blood\s+cell[:\s]*([0-9]+\.?[0-9]*)',
            r'leucocytes?[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'platelet_count': [
            r'platelet[s]?[:\s]*([0-9]+\.?[0-9]*)',
            r'plt[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'rbc_count': [
            r'rbc[:\s]*([0-9]+\.?[0-9]*)',
            r'red\s+blood\s+cell[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'cholesterol': [
            r'cholesterol[:\s]*([0-9]+\.?[0-9]*)',
            r'total\s+cholesterol[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'hdl': [
            r'hdl[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'ldl': [
            r'ldl[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'triglycerides': [
            r'triglyceride[s]?[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'urea': [
            r'urea[:\s]*([0-9]+\.?[0-9]*)',
            r'blood\s+urea[:\s]*([0-9]+\.?[0-9]*)',
        ],
        'bilirubin': [
            r'bilirubin[:\s]*([0-9]+\.?[0-9]*)',
            r'total\s+bilirubin[:\s]*([0-9]+\.?[0-9]*)',
        ]
    }
    
    # Normal ranges for flagging abnormal values
    NORMAL_RANGES = {
        'hemoglobin': {'male': (13.0, 17.0), 'female': (12.0, 15.0), 'unit': 'g/dL'},
        'blood_sugar': {'fasting': (70, 100), 'random': (70, 140), 'unit': 'mg/dL'},
        'creatinine': {'male': (0.7, 1.3), 'female': (0.6, 1.1), 'unit': 'mg/dL'},
        'liver_enzyme': {'alt': (7, 56), 'ast': (10, 40), 'unit': 'U/L'},
        'wbc_count': {'range': (4000, 11000), 'unit': 'cells/μL'},
        'platelet_count': {'range': (150000, 450000), 'unit': 'cells/μL'},
        'cholesterol': {'range': (0, 200), 'unit': 'mg/dL'},
        'hdl': {'range': (40, 60), 'unit': 'mg/dL'},
        'ldl': {'range': (0, 100), 'unit': 'mg/dL'},
    }
    
    @staticmethod
    def extract_from_image(image_path: str) -> Dict:
        """
        Extract text from image using OCR
        
        Args:
            image_path: Path to image file
        
        Returns:
            Dictionary with extracted text and confidence
        """
        if not HAS_OCR:
            return {
                'success': False,
                'error': 'OCR libraries not installed'
            }
        
        try:
            # Load image
            image = Image.open(image_path)
            
            # Perform OCR with configuration for better accuracy
            custom_config = r'--oem 3 --psm 6'
            text = pytesseract.image_to_string(image, config=custom_config)
            
            # Get confidence scores
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data['conf'] if conf != '-1']
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            return {
                'success': True,
                'text': text,
                'confidence': round(avg_confidence, 2),
                'method': 'pytesseract'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def extract_from_pdf(pdf_path: str) -> Dict:
        """
        Extract text from PDF by converting to images first
        
        Args:
            pdf_path: Path to PDF file
        
        Returns:
            Dictionary with extracted text
        """
        if not HAS_OCR:
            return {
                'success': False,
                'error': 'OCR libraries not installed'
            }
        
        try:
            # Convert PDF pages to images
            images = pdf2image.convert_from_path(pdf_path, dpi=300)
            
            all_text = []
            total_confidence = 0
            
            for i, image in enumerate(images):
                # Extract text from each page
                custom_config = r'--oem 3 --psm 6'
                page_text = pytesseract.image_to_string(image, config=custom_config)
                all_text.append(f"\n--- Page {i+1} ---\n{page_text}")
                
                # Get confidence
                data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
                confidences = [int(conf) for conf in data['conf'] if conf != '-1']
                if confidences:
                    total_confidence += sum(confidences) / len(confidences)
            
            avg_confidence = total_confidence / len(images) if images else 0
            
            return {
                'success': True,
                'text': '\n'.join(all_text),
                'confidence': round(avg_confidence, 2),
                'pages': len(images),
                'method': 'pdf2image + pytesseract'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def extract_lab_values(text: str) -> Dict:
        """
        Extract lab values from OCR text using pattern matching
        
        Args:
            text: OCR extracted text
        
        Returns:
            Dictionary of extracted lab values
        """
        # Convert to lowercase for case-insensitive matching
        text_lower = text.lower()
        
        extracted_values = {}
        extraction_details = {}
        
        for lab_name, patterns in LabReportOCR.LAB_PATTERNS.items():
            for pattern in patterns:
                match = re.search(pattern, text_lower, re.IGNORECASE)
                if match:
                    try:
                        value = float(match.group(1))
                        extracted_values[lab_name] = value
                        extraction_details[lab_name] = {
                            'value': value,
                            'pattern_matched': pattern,
                            'raw_match': match.group(0)
                        }
                        break  # Found value, move to next lab test
                    except (ValueError, IndexError):
                        continue
        
        return {
            'values': extracted_values,
            'details': extraction_details,
            'total_extracted': len(extracted_values)
        }
    
    @staticmethod
    def flag_abnormal_values(
        extracted_values: Dict,
        patient_gender: str = 'male'
    ) -> Dict:
        """
        Flag abnormal lab values based on normal ranges
        
        Args:
            extracted_values: Dictionary of lab values
            patient_gender: 'male' or 'female'
        
        Returns:
            Dictionary with abnormal flags
        """
        flags = {}
        
        for lab_name, value in extracted_values.items():
            if lab_name in LabReportOCR.NORMAL_RANGES:
                range_info = LabReportOCR.NORMAL_RANGES[lab_name]
                
                # Get appropriate range
                if patient_gender in range_info:
                    min_val, max_val = range_info[patient_gender]
                elif 'range' in range_info:
                    min_val, max_val = range_info['range']
                else:
                    continue
                
                # Check if abnormal
                is_normal = min_val <= value <= max_val
                
                if value < min_val:
                    status = 'LOW'
                    severity = 'warning'
                elif value > max_val:
                    status = 'HIGH'
                    severity = 'warning'
                    
                    # Critical high values
                    if lab_name == 'blood_sugar' and value > 200:
                        severity = 'critical'
                    elif lab_name == 'creatinine' and value > 2.0:
                        severity = 'critical'
                else:
                    status = 'NORMAL'
                    severity = 'normal'
                
                flags[lab_name] = {
                    'value': value,
                    'normal_range': f"{min_val}-{max_val}",
                    'unit': range_info.get('unit', ''),
                    'status': status,
                    'severity': severity,
                    'is_normal': is_normal
                }
        
        return flags
    
    @staticmethod
    def process_lab_report(
        file_path: str,
        patient_gender: str = 'male'
    ) -> Dict:
        """
        Complete lab report processing pipeline
        
        Args:
            file_path: Path to lab report file (PDF or image)
            patient_gender: Patient gender for range checking
        
        Returns:
            Complete processing result
        """
        result = {
            'success': False,
            'file_path': file_path,
            'timestamp': datetime.now().isoformat(),
            'ocr_result': None,
            'extracted_values': {},
            'abnormal_flags': {},
            'errors': []
        }
        
        try:
            # Determine file type
            file_ext = os.path.splitext(file_path)[1].lower()
            
            # Extract text based on file type
            if file_ext == '.pdf':
                ocr_result = LabReportOCR.extract_from_pdf(file_path)
            elif file_ext in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp']:
                ocr_result = LabReportOCR.extract_from_image(file_path)
            else:
                result['errors'].append(f'Unsupported file type: {file_ext}')
                return result
            
            result['ocr_result'] = ocr_result
            
            if not ocr_result['success']:
                result['errors'].append(ocr_result.get('error', 'OCR failed'))
                return result
            
            # Extract lab values
            extraction = LabReportOCR.extract_lab_values(ocr_result['text'])
            result['extracted_values'] = extraction['values']
            result['extraction_details'] = extraction['details']
            
            # Flag abnormal values
            if extraction['values']:
                result['abnormal_flags'] = LabReportOCR.flag_abnormal_values(
                    extraction['values'],
                    patient_gender
                )
            
            result['success'] = True
            result['extraction_status'] = 'SUCCESS' if extraction['values'] else 'NO_VALUES_FOUND'
            
        except Exception as e:
            result['errors'].append(str(e))
            result['extraction_status'] = 'FAILED'
        
        return result
    
    @staticmethod
    def generate_summary_report(processing_result: Dict) -> str:
        """
        Generate human-readable summary of lab report
        
        Args:
            processing_result: Result from process_lab_report()
        
        Returns:
            Formatted summary string
        """
        if not processing_result['success']:
            return f"❌ Processing failed: {', '.join(processing_result['errors'])}"
        
        lines = []
        lines.append("🔬 **Lab Report Analysis**\n")
        
        # OCR Info
        if processing_result['ocr_result']:
            confidence = processing_result['ocr_result'].get('confidence', 0)
            lines.append(f"📄 OCR Confidence: {confidence:.1f}%")
        
        # Extracted values
        extracted = processing_result['extracted_values']
        if not extracted:
            lines.append("\n⚠️ No lab values could be extracted from the report.")
            return '\n'.join(lines)
        
        lines.append(f"\n✅ Successfully extracted {len(extracted)} values:\n")
        
        # Show values with flags
        flags = processing_result.get('abnormal_flags', {})
        
        for lab_name, value in extracted.items():
            display_name = lab_name.replace('_', ' ').title()
            
            if lab_name in flags:
                flag_info = flags[lab_name]
                status_icon = {
                    'NORMAL': '✅',
                    'LOW': '⬇️',
                    'HIGH': '⬆️'
                }.get(flag_info['status'], '❓')
                
                severity_color = {
                    'normal': '',
                    'warning': '⚠️',
                    'critical': '🚨'
                }.get(flag_info['severity'], '')
                
                lines.append(
                    f"{status_icon} **{display_name}**: {value} {flag_info['unit']} "
                    f"(Normal: {flag_info['normal_range']}) {severity_color}"
                )
            else:
                lines.append(f"📊 **{display_name}**: {value}")
        
        # Critical warnings
        critical_values = [
            name for name, flag in flags.items()
            if flag['severity'] == 'critical'
        ]
        
        if critical_values:
            lines.append("\n🚨 **CRITICAL ABNORMALITIES DETECTED:**")
            for lab_name in critical_values:
                flag_info = flags[lab_name]
                lines.append(
                    f"  • {lab_name.replace('_', ' ').title()}: "
                    f"{flag_info['value']} {flag_info['unit']} (Status: {flag_info['status']})"
                )
            lines.append("\n⚠️ **Immediate medical attention recommended**")
        
        return '\n'.join(lines)


# Convenience functions
def extract_lab_values_from_file(file_path: str, patient_gender: str = 'male') -> Dict:
    """Quick function to extract lab values from file"""
    return LabReportOCR.process_lab_report(file_path, patient_gender)


def save_lab_report_to_db(
    db,
    LabReport,
    patient_id: int,
    file_path: str,
    processing_result: Dict
) -> Dict:
    """
    Save lab report extraction results to database
    
    Args:
        db: Database session
        LabReport: LabReport model class
        patient_id: Patient ID
        file_path: Path to uploaded file
        processing_result: Result from process_lab_report()
    
    Returns:
        Save result
    """
    try:
        # Generate report ID
        report_id = f"LAB{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Extract values
        values = processing_result.get('extracted_values', {})
        
        # Create lab report record
        lab_report = LabReport(
            patient_id=patient_id,
            report_id=report_id,
            filename=os.path.basename(file_path),
            file_path=file_path,
            file_type=os.path.splitext(file_path)[1],
            extracted_text=processing_result.get('ocr_result', {}).get('text', ''),
            hemoglobin=values.get('hemoglobin'),
            blood_sugar=values.get('blood_sugar'),
            creatinine=values.get('creatinine'),
            liver_enzyme=values.get('liver_enzyme'),
            wbc_count=values.get('wbc_count'),
            platelet_count=values.get('platelet_count'),
            ocr_confidence=processing_result.get('ocr_result', {}).get('confidence'),
            extraction_status=processing_result.get('extraction_status', 'FAILED'),
            extraction_errors=json.dumps(processing_result.get('errors', [])),
            processed_at=datetime.utcnow()
        )
        
        db.session.add(lab_report)
        db.session.commit()
        
        return {
            'success': True,
            'report_id': report_id,
            'values_extracted': len(values)
        }
    
    except Exception as e:
        db.session.rollback()
        return {
            'success': False,
            'error': str(e)
        }